<div class="content mt-3">
			<div class="card bg-secondary bg-secondary">
				<div class="card-body">
					<a href="index.php" class="btn text-light">Dashboard</a>
					<a href="kategori.php" class="btn text-light">Kategori Buku</a>
					<a href="buku.php" class="btn text-light">Buku</a>
					<a href="koleksi.php" class="btn text-light">Koleksi Buku</a>
					<a href="laporan_peminjaman.php" class="btn text-light">Laporan Peminjaman</a>
					<a href="../logout.php" class="btn text-light">Logout</a>
				</div>
			</div>
</div>