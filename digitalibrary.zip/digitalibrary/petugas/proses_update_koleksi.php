<?php 
// koneksi database
include '../koneksi.php';
   
// menangkap data yang di kirim dari form
$KategoribukuID = $_POST['KategoribukuID'];
$BukuID = $_POST['BukuID'];
$KategoriID = $_POST['KategoriID'];
 
// menginput data ke database
mysqli_query($koneksi,"update kategoribuku_relasi set BukuID='$BukuID', KategoriID='$KategoriID' where KategoribukuID='$KategoribukuID'");
 
// mengalihkan halaman kembali ke kategori.php
header("location:koleksi.php?pesan=update");
 
?>