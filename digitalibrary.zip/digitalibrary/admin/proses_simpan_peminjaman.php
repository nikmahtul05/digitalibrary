<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$PeminjamanID = $_POST['PeminjamanID'];
$UserID = md5($_POST['UserID']);
$BukuID = $_POST['BukuID'];
$TanggalPeminjaman = $_POST['TanggalPeminjaman'];
$TanggalPengembalian = $_POST['TanggalPengembalian'];
$StatusPeminjaman = $_POST['StatusPeminjaman'];

 
// menginput data ke database
mysqli_query($koneksi,"INSERT INTO `peminjaman` (`PeminjamanID`, `UserID`, `BukuID`, `TanggalPeminjaman`, `TanggalPengembalian`, `StatusPeminjaman`) VALUES (NULL, '12', '12', '2024-02-14', '2024-02-13', 'pinjam');");
 
// mengalihkan halaman kembali ke index.php
header("location:peminjaman.php?pesan=simpan");
 
?>